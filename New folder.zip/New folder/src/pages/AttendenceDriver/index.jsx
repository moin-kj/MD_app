import React from "react";
import AttendenceDriverComponent from "../../components/attendenceDriver";
const AttendenceDriver = () => {
  return (
    <AttendenceDriverComponent />
  );
};

export default AttendenceDriver;
