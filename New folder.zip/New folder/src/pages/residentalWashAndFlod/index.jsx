import React from 'react'
import TableManagement from '../../components/ResidentalWashAndFlod/TableManagement'
const ResidentalWashFlod = () => {
  return (
    <TableManagement />
  )
}
export default ResidentalWashFlod;